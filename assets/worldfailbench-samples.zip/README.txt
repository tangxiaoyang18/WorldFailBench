WorldFailBench sample scenes

These are initial RGB observations from simulator rollouts, with simulator task-success labels and ordered task-stage vocabularies.
A first frame does not show the eventual outcome. The success field describes the completed rollout.
The stages field lists task stages; it does not identify the failed stage of an individual episode.

This is a small illustrative subset of the dataset, not the complete benchmark.
